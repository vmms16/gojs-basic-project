import { Component, OnInit } from '@angular/core';
import * as go from 'gojs';

@Component({
selector: 'app-teste',
templateUrl: './teste.component.html',
styleUrls: ['./teste.component.css']
})
export class TesteComponent implements OnInit {


    public state = {
        // Diagram state props
        diagramNodeData: [
            {key: 0, id: 'Alpha', text: "Alpha", color: 'lightblue'},
            {key: 1, id: 'Beta', text: "Beta", color: 'orange', 'parent': 0 },
            {key: 2, id: 'Gama', text: "Game", color: 'purple', 'parent': 0},
            {key: 3, id: 'Epslon', text: "Epslon", color: 'red', 'parent': 2 },
            {key: 4, id: 'Zeta', text: "Zeta", color: 'green',  'parent': 2}
        ],
        diagramLinkData: [
            { key: -1, from: 'Alpha', to: 'Beta' },
            { key: 0, from: 'Alpha', to: 'Gama'},
            { key: 1, from: 'Gama', to: 'Epslon'},
            { key: 2, from: 'Gama', to: 'Zeta'}
        ],
        diagramModelData: { prop: 'value' },
        skipsDiagramUpdate: false,

        // Palette state props
        paletteNodeData: [
            { key: 'PaletteNode1', color: 'firebrick' },
            { key: 'PaletteNode2', color: 'blueviolet' }
        ]
    }; // end state object

    public diagramDivClassName: string = 'myDiagramDiv';
    public paletteDivClassName = 'myPaletteDiv';

    constructor() { }

    ngOnInit(): void {
    }

    helloWorld() {   
        //function definition 
        console.log("function called");
    }

    myDiagram :go.Diagram | undefined;

    public ngAfterViewInit() {
        this.initDiagram();
    }

    initDiagram(): go.Diagram {
        const $ = go.GraphObject.make;
        
        this.myDiagram = $(go.Diagram, 'myDiagramDiv', 
        {
            'undoManager.isEnabled': true,
            maxSelectionCount: 1,
            validCycle: go.Diagram.CycleDestinationTree,
            "clickCreatingTool.archetypeNodeData": {
                text: "Novo", 
                color: 'red'
            },
            'clickCreatingTool.insertPart': this.addNode,
            layout: $(go.TreeLayout),
            model: $(go.GraphLinksModel,
                {
                    nodeKeyProperty: 'id',
                    linkKeyProperty: 'key' // IMPORTANT! must be defined for merges and data sync when using GraphLinksModel
                }
            )
        });

        // define the Node template
        this.myDiagram.nodeTemplate =
            $(go.Node, 'Auto',
                { doubleClick: this.nodeDoubleClick },
                $(go.Shape, 'RoundedRectangle', { stroke: null },
                new go.Binding('fill', 'color')
                ),
                $(go.TextBlock, { margin: 8, editable: true },
                new go.Binding('text').makeTwoWay())
            );

        this.myDiagram.linkTemplate = $(go.Link,
            {routing: go.Link.Orthogonal, corner: 7},
            $(go.Shape, { strokeWidth: 3.5, stroke: "#5b5b5b" })
        );


        // this.initEventDiagram();
        this.helloWorld();

        this.myDiagram.model = new go.TreeModel(this.state.diagramNodeData);
        // this.myDiagram.link = new go.Link(this.state.diagramLinkData);

        return this.myDiagram;
    }

    initEventDiagram() : void {
        this.myDiagram?.addDiagramListener('Modified', function(e) {
            // console.log(e);
        });
    }

    public addNode (loc: go.Point) : go.Part {
        var node = go.ClickCreatingTool.prototype.insertPart.call(this, loc);
        return node;
    }

    public nodeDoubleClick(e: go.InputEvent, obj: any) {
         console.log("DC TESTE")
        var clicked = obj.part;
        if (clicked !== null) {
          var thisemp = clicked.data;
          this.myDiagram?.startTransaction("add employee");
          var newemp = {
            text: "Alpha", 
            color: "red",
            parent: thisemp.key
          };
          this.myDiagram?.model.addNodeData(newemp);
          this.myDiagram?.commitTransaction("add employee");
        }
      }

    public initPalette(): go.Palette {
        const $ = go.GraphObject.make;
        const palette = $(go.Palette);
      
        // define the Node template
        palette.nodeTemplate =
          $(go.Node, 'Auto',
            $(go.Shape, 'RoundedRectangle', { stroke: null },
              new go.Binding('fill', 'color')
            ),
            $(go.TextBlock, { margin: 8 },
              new go.Binding('text', 'key'))
          );
      
        palette.model = $(go.GraphLinksModel,
            {
                linkKeyProperty: 'key'  // IMPORTANT! must be defined for merges and data sync when using GraphLinksModel
            });
      
        return palette;
    }

    public diagramModelChange = function(changes: go.IncrementalData) {
        // console.log(changes);
        // see gojs-angular-basic for an example model changed handler that preserves immutability
        // when setting state, be sure to set skipsDiagramUpdate: true since GoJS already has this update
    };
}
